import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const steps = [
  '사업장 정보',
  '근로자 정보', 
  '계약 기간',
  '근무 조건',
  '근로시간',
  '임금 조건',
  '기타 사항',
  '최종 확인',
];

// 시간 계산 유틸
function getMinutes(t) {
  if (!t) return 0;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function getHourStr(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}시간${m ? ' ' + m + '분' : ''}`;
}

function calcWorkStats(form) {
  let totalWeek = 0, totalMonth = 0, night = 0, over = 0;
  const dayStats = {};
  const NIGHT_START = 22 * 60, NIGHT_END = 6 * 60; // 22:00~06:00
  form.days.forEach(day => {
    let s, e, br;
    if (form.workTimeType === 'same') {
      s = getMinutes(form.commonStart);
      e = getMinutes(form.commonEnd);
      br = Number(form.commonBreak) || 0;
    } else {
      s = getMinutes(form.dayTimes[day]?.start);
      e = getMinutes(form.dayTimes[day]?.end);
      br = Number(form.dayTimes[day]?.break) || 0;
    }
    if ((!s && !e) || e === s) { dayStats[day] = { work: 0, night: 0, over: 0 }; return; }
    let work = e > s ? e - s : (e + 24 * 60) - s;
    work = Math.max(0, work - br); // 휴게시간 차감
    let nightMin = 0;
    // 야간근로 계산
    for (let t = s; t < s + work + br; t += 10) {
      const cur = t % (24 * 60);
      if (cur >= NIGHT_START || cur < NIGHT_END) nightMin += 10;
    }
    // 연장근로(1일 8시간 초과)
    let overMin = work > 480 ? work - 480 : 0;
    dayStats[day] = { work, night: nightMin, over: overMin };
    totalWeek += work;
    night += nightMin;
    over += overMin;
  });
  totalMonth = Math.round(totalWeek * 4.345); // 월평균 주수
  return { dayStats, totalWeek, totalMonth, night, over };
}

function ContractForm() {
  const [form, setForm] = useState({
    // 사업장 정보
    storeName: '',
    owner: '',
    address: '',
    addressDetail: '',
    storeContact: '',
    // 근로자 정보
    name: '',
    birth: (() => {
      const today = new Date();
      const eighteenYearsAgo = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
      return eighteenYearsAgo.toISOString().split('T')[0];
    })(),
    contact: '',
    workerAddress: '',
    workerAddressDetail: '',
    // 계약 기간
    periodStart: '',
    periodEnd: '',
    probationPeriod: '',
    // 근무 조건
    workLocation: '',
    jobDesc: '',
    position: '',
    // 근로시간
    workTimeType: '', // 'same' or 'diff'
    days: [],
    dayTimes: {}, // { '월': {start: '', end: '', break: ''}, ... }
    commonStart: '',
    commonEnd: '',
    commonBreak: '',
    // 임금 조건
    salaryType: 'monthly', // 'monthly' or 'hourly'
    baseSalary: '',
    hourlyWage: '',
    allowances: '',
    totalSalary: '',
    payday: '',
    paymentMethod: '계좌이체',
    // 기타 사항
    socialInsurance: true,
    termination: '',
    confidentiality: true,
    contractCopies: 2,
  });
  const [step, setStep] = useState(0);
  const daysOfWeek = ['월', '화', '수', '목', '금', '토', '일'];
  const navigate = useNavigate();

  // 카카오 주소 API 스크립트 동적 로드
  React.useEffect(() => {
    if (!window.daum) {
      const script = document.createElement('script');
      script.src = 'https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, checked, dataset } = e.target;
    
    if (name === 'days') {
      setForm((prev) => {
        const newDays = checked
          ? [...prev.days, value]
          : prev.days.filter((d) => d !== value);
        // days에서 빠진 요일의 시간 정보도 삭제
        const newDayTimes = { ...prev.dayTimes };
        if (!checked) delete newDayTimes[value];
        return { ...prev, days: newDays, dayTimes: newDayTimes };
      });
    } else if (name === 'dayStart' || name === 'dayEnd' || name === 'dayBreak') {
      const day = dataset.day;
      setForm((prev) => ({
        ...prev,
        dayTimes: {
          ...prev.dayTimes,
          [day]: {
            ...prev.dayTimes[day],
            [name.replace('day', '').toLowerCase()]: value,
          },
        },
      }));
    } else {
      setForm((prev) => ({
        ...prev,
        [name]: e.target.type === 'checkbox' ? checked : value,
      }));
    }
  };

  const handleAddressSearch = () => {
    if (window.daum && window.daum.Postcode) {
      new window.daum.Postcode({
        oncomplete: function(data) {
          setForm(prev => ({
            ...prev,
            address: data.address,
            addressDetail: ''
          }));
        }
      }).open();
    } else {
      alert('주소 검색 서비스를 불러오는 중입니다. 잠시 후 다시 시도해주세요.');
    }
  };

  const handleSavePDF = async () => {
    // 표준근로계약서 HTML 생성
    const contractDate = new Date().toLocaleDateString('ko-KR', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });

    // 시급제 계산을 위한 변수들
    const workStats3 = calcWorkStats(form);
    const hourlyWage = Number(form.hourlyWage) || 0;
    const allowances = Number(form.allowances) || 0;
    const basePay = Number(form.baseSalary) || 0;
    const totalPay = basePay + allowances;
    
    // 시급제 계산
    let calculatedMonthlySalary = 0, overtimePay = 0, nightPay = 0, monthlyHolidayPay = 0, totalCalculatedSalary = 0;
    let monthlyWorkHours = 0, overtimeHours = 0, nightHours = 0, weeklyOvertime = 0;
    
    if (form.salaryType === 'hourly' && hourlyWage > 0) {
      monthlyWorkHours = workStats3.totalMonth;
      const weeklyWorkHours = workStats3.totalWeek;
      
      calculatedMonthlySalary = hourlyWage * (monthlyWorkHours / 60);
      overtimeHours = workStats3.over;
      overtimePay = hourlyWage * 0.5 * (overtimeHours / 60);
      nightHours = workStats3.night;
      nightPay = hourlyWage * 0.5 * (nightHours / 60);
      
      weeklyOvertime = Math.max(0, weeklyWorkHours - 40);
      const weeklyHolidayPay = hourlyWage * (weeklyOvertime / 60);
      monthlyHolidayPay = weeklyHolidayPay * 4.345;
      
      totalCalculatedSalary = calculatedMonthlySalary + overtimePay + nightPay + monthlyHolidayPay + allowances;
    }
    
    const baseSalary = form.salaryType === 'monthly' 
      ? (form.baseSalary ? Number(form.baseSalary).toLocaleString() : '[0,000,000]')
      : (form.hourlyWage ? `${form.hourlyWage.toLocaleString()}원/시간` : '[0,000]원/시간');
    const allowancesText = form.allowances ? Number(form.allowances).toLocaleString() : '[식대, 교통비, 직책수당 등]';
    const totalSalary = form.salaryType === 'monthly'
      ? (form.baseSalary && form.allowances 
          ? (Number(form.baseSalary) + Number(form.allowances)).toLocaleString() 
          : '[0,000,000]')
      : (form.salaryType === 'hourly' && hourlyWage > 0 
          ? `${Math.round(totalCalculatedSalary).toLocaleString()}원 (시급제 계산)`
          : '[시급제 계산 참조]');

    const workTimeText = form.workTimeType === 'same' 
      ? `1일 8시간, 1주 40시간 (${form.days.join(', ')}, ${form.commonStart || '09:00'} ~ ${form.commonEnd || '18:00'})`
      : `요일별 상이 (${form.days.join(', ')})`;

    const breakText = form.workTimeType === 'same'
      ? `1일 1시간 (근로시간 중 ${form.commonStart || '12:00'} ~ ${form.commonEnd || '13:00'})`
      : '요일별 상이';

    const htmlContent = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>표준 근로계약서</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom font for better readability */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f0f4f8; /* Light blue-gray background */
        }
        /* Custom scrollbar for a cleaner look */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #e2e8f0;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #94a3b8;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #64748b;
        }
        /* Styling for the main content area */
        .contract-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 2.5rem;
            background: linear-gradient(135deg, #ffffff, #f8fafc); /* Subtle gradient background */
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
        }
        /* Section title styling */
        .section-title {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e293b; /* Darker text for titles */
            margin-top: 2rem;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #cbd5e1; /* Light gray border */
        }
        /* Icon styling (using simple shapes/emojis as placeholders for clip art) */
        .icon {
            font-size: 1.8rem;
            line-height: 1;
        }
        /* Table styling */
        .contract-table th, .contract-table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }
        .contract-table th {
            background-color: #f8fafc;
            font-weight: 600;
            color: #475569;
        }
        .contract-table tr:last-child td {
            border-bottom: none;
        }
        /* Highlighted text for important notes */
        .note {
            background-color: #e0f2fe; /* Light blue background */
            border-left: 5px solid #38b2ac; /* Teal border */
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1.5rem;
            color: #0c4a6e;
        }
        @media print {
            body {
                background: white;
            }
            .contract-container {
                margin: 0;
                padding: 1rem;
                box-shadow: none;
                border-radius: 0;
                border: none;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body class="p-4 sm:p-6 md:p-8">
    <div class="contract-container">
        <!-- Header Section -->
        <header class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-blue-800 mb-4 tracking-tight">
                <span class="inline-block transform -rotate-3 text-yellow-500">✨</span> 표준 근로계약서 <span class="inline-block transform rotate-3 text-green-500">🤝</span>
            </h1>
            <p class="text-lg text-gray-600">
                근로기준법을 준수하며, 상호 신뢰와 존중을 바탕으로 합니다.
            </p>
            <div class="mt-6 flex justify-center space-x-4">
                <span class="inline-block p-3 bg-blue-100 rounded-full shadow-md">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </span>
                <span class="inline-block p-3 bg-green-100 rounded-full shadow-md">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.592 1L21 12m-2.592 3A2 2 0 0112 16c-1.11 0-2.08-.402-2.592-1M5 12h.01M12 12h.01M19 12h.01M6 12a3 3 0 11-6 0 3 3 0 016 0zm0 0v1h.586a1 1 0 01.707.293l2.414 2.414a1 1 0 00.707.293h3.172a2 2 0 001.414-.586L19 12V6a2 2 0 00-2-2h-3.172a2 2 0 00-1.414.586L11 7.414a2 2 0 01-.586.707H6z"></path></svg>
                </span>
            </div>
        </header>

        <!-- General Information Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">📄</span> 제1조 (계약의 목적)
            </h2>
            <p class="text-gray-700 leading-relaxed">
                본 계약은 ${form.storeName || '[회사명]'} (이하 "갑"이라 한다)과 ${form.name || '[근로자명]'} (이하 "을"이라 한다) 간에 근로기준법 및 기타 관련 법규에 의거하여 근로 조건을 명확히 하고, 상호 간의 권리와 의무를 성실히 이행함을 목적으로 한다.
            </p>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 계약의 기본 원칙</p>
                <p>근로계약은 근로기준법 제2조에 따라 근로자와 사용자 간에 근로조건을 정하는 계약입니다. 본 계약은 법이 정한 최저 기준을 준수하며, 근로기준법에 미달하는 근로조건은 무효가 되고 그 부분은 근로기준법에 따릅니다 (근로기준법 제6조).</p>
            </div>
        </section>

        <!-- Parties Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">👥</span> 제2조 (당사자)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>갑 (사용자)</strong></td>
                            <td>
                                <p><strong>회사명:</strong> ${form.storeName || '[회사명]'}</p>
                                <p><strong>대표자:</strong> ${form.owner || '[대표자명]'}</p>
                                <p><strong>주소:</strong> ${form.address || '[회사 주소]'} ${form.addressDetail || ''}</p>
                                <p><strong>연락처:</strong> ${form.storeContact || '[회사 연락처]'}</p>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>을 (근로자)</strong></td>
                            <td>
                                <p><strong>성명:</strong> ${form.name || '[근로자명]'}</p>
                                <p><strong>생년월일:</strong> ${form.birth || '[YYYY년 MM월 DD일]'}</p>
                                <p><strong>주소:</strong> ${form.workerAddress || '[근로자 주소]'} ${form.workerAddressDetail || ''}</p>
                                <p><strong>연락처:</strong> ${form.contact || '[근로자 연락처]'}</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 당사자 정보의 중요성</p>
                <p>사용자와 근로자의 정확한 정보는 계약의 유효성을 확인하고, 향후 발생할 수 있는 법적 분쟁 시 당사자를 명확히 하는 데 필수적입니다. 특히 근로자의 개인정보는 「개인정보 보호법」에 따라 안전하게 관리되어야 합니다.</p>
            </div>
        </section>

        <!-- Employment Period Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">📅</span> 제3조 (근로계약 기간)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>계약 시작일</strong></td>
                            <td>${form.periodStart || '[YYYY년 MM월 DD일]'}</td>
                        </tr>
                        <tr>
                            <td><strong>계약 종료일</strong></td>
                            <td>${form.periodEnd || '기간의 정함이 없음'}</td>
                        </tr>
                        <tr>
                            <td><strong>수습 기간</strong></td>
                            <td>${form.probationPeriod || '없음'}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 근로계약 기간 및 수습</p>
                <p>근로계약은 기간을 정할 수도 있고(기간제 근로), 기간을 정하지 않을 수도 있습니다(정규직). 기간제 근로계약은 원칙적으로 2년을 초과할 수 없으며, 2년을 초과하여 사용하는 경우 기간의 정함이 없는 근로자로 간주됩니다 (기간제법 제4조).</p>
                <p>수습 기간은 근로자의 업무 적응 및 능력 평가를 위한 기간으로, 근로기준법 제35조 및 동법 시행령 제3조에 따라 3개월 이내의 수습 근로자에 대해서는 해고예고 규정이 적용되지 않을 수 있으며, 최저임금의 90% 이상을 지급할 수 있습니다.</p>
            </div>
        </section>

        <!-- Work Location & Job Description Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">📍</span> 제4조 (근무 장소 및 업무 내용)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>근무 장소</strong></td>
                            <td>${form.workLocation || form.address || '[회사 주소]'}</td>
                        </tr>
                        <tr>
                            <td><strong>업무 내용</strong></td>
                            <td>${form.jobDesc || '[담당 업무 상세 기재]'}</td>
                        </tr>
                        <tr>
                            <td><strong>직위/직책</strong></td>
                            <td>${form.position || '[직위/직책]'}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 근무 장소 및 업무의 명확화</p>
                <p>근무 장소와 업무 내용은 근로계약의 중요한 요소입니다. 이는 근로자의 권리 보호뿐만 아니라, 사용자의 인사권 행사 범위에도 영향을 미칩니다. 업무 내용이 포괄적일 경우 향후 업무 지시 범위에 대한 분쟁이 발생할 수 있으므로 최대한 구체적으로 명시하는 것이 좋습니다.</p>
            </div>
        </section>

        <!-- Working Hours & Rest Hours Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">⏰</span> 제5조 (근로시간 및 휴게시간)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>소정 근로시간</strong></td>
                            <td>${workTimeText}</td>
                        </tr>
                        <tr>
                            <td><strong>휴게 시간</strong></td>
                            <td>${breakText}</td>
                        </tr>
                        <tr>
                            <td><strong>연장/야간/휴일 근로</strong></td>
                            <td>갑의 지시 또는 을의 동의 하에 가능하며, 근로기준법에 따라 가산수당 지급</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 근로시간 및 가산수당</p>
                <p>근로기준법 제50조에 따라 1주간의 근로시간은 40시간을, 1일의 근로시간은 8시간을 초과할 수 없습니다. 휴게시간은 근로시간 4시간에 30분 이상, 8시간에 1시간 이상을 부여해야 하며 (근로기준법 제54조), 자유롭게 이용할 수 있어야 합니다.</p>
                <p>연장근로(1주 12시간 한도), 야간근로(오후 10시부터 오전 6시까지), 휴일근로에 대해서는 통상임금의 50% 이상을 가산하여 지급해야 합니다 (근로기준법 제56조). 주 52시간 근무제는 연장근로를 포함한 총 근로시간을 의미합니다.</p>
            </div>
        </section>

        <!-- Holidays & Leaves Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">🏖️</span> 제6조 (휴일 및 휴가)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>주휴일</strong></td>
                            <td>매주 토요일 또는 일요일 (주 1회 유급 휴일)</td>
                        </tr>
                        <tr>
                            <td><strong>법정 공휴일</strong></td>
                            <td>「관공서의 공휴일에 관한 규정」에 따른 유급 휴일</td>
                        </tr>
                        <tr>
                            <td><strong>연차 유급 휴가</strong></td>
                            <td>근로기준법에 따라 부여 (입사 1년 미만 시 1개월 개근 시 1일, 1년 이상 시 15일 등)</td>
                        </tr>
                        <tr>
                            <td><strong>기타 휴가</strong></td>
                            <td>경조사 휴가 등 회사의 취업규칙에 따름</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 휴일 및 연차 유급 휴가</p>
                <p>주휴일은 1주간 소정근로일을 개근한 근로자에게 주어지는 유급 휴일입니다 (근로기준법 제55조). 법정 공휴일은 2022년부터 모든 사업장에 유급 휴일로 적용됩니다.</p>
                <p>연차 유급 휴가는 근로기준법 제60조에 따라 1년간 80% 이상 출근한 근로자에게 15일이 부여되며, 3년 이상 계속 근로 시 2년마다 1일씩 가산됩니다. 1년 미만 근로자 또는 1년간 80% 미만 출근한 근로자에게는 1개월 개근 시 1일의 유급휴가가 부여됩니다. 사용자는 근로자의 연차 사용을 촉진할 의무가 있습니다.</p>
            </div>
        </section>

        <!-- Wages Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">💰</span> 제7조 (임금)
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-sm contract-table">
                    <thead>
                        <tr>
                            <th class="rounded-tl-lg">구분</th>
                            <th>내용</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>월 기본급</strong></td>
                            <td>${baseSalary}원</td>
                        </tr>
                        <tr>
                            <td><strong>제수당</strong></td>
                            <td>${allowancesText}원</td>
                        </tr>
                        <tr>
                            <td><strong>총 월 임금</strong></td>
                            <td>${totalSalary}원 (세전)</td>
                        </tr>
                        ${form.salaryType === 'hourly' && hourlyWage > 0 ? `
                        <tr>
                            <td><strong>시급제 계산 내역</strong></td>
                            <td>
                                <p>• 기본급: ${hourlyWage.toLocaleString()}원 × ${Math.round(workStats3.totalMonth / 60)}시간 = ${Math.round(calculatedMonthlySalary).toLocaleString()}원</p>
                                <p>• 연장수당: ${hourlyWage.toLocaleString()}원 × 0.5 × ${Math.round(workStats3.over / 60)}시간 = ${Math.round(overtimePay).toLocaleString()}원</p>
                                <p>• 야간수당: ${hourlyWage.toLocaleString()}원 × 0.5 × ${Math.round(workStats3.night / 60)}시간 = ${Math.round(nightPay).toLocaleString()}원</p>
                                <p>• 주휴수당: ${hourlyWage.toLocaleString()}원 × ${Math.round(Math.max(0, workStats3.totalWeek - 40) / 60)}시간 × 4.345주 = ${Math.round(monthlyHolidayPay).toLocaleString()}원</p>
                                <p>• 제수당: ${allowancesText}원</p>
                            </td>
                        </tr>
                        ` : ''}
                        <tr>
                            <td><strong>임금 지급일</strong></td>
                            <td>${form.payday || '매월 25일'}</td>
                        </tr>
                        <tr>
                            <td><strong>지급 방법</strong></td>
                            <td>${form.paymentMethod || '을의 지정 계좌로 입금'}</td>
                        </tr>
                        <tr>
                            <td><strong>임금 계산 기간</strong></td>
                            <td>매월 1일부터 말일까지</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 임금 지급의 원칙</p>
                <p>임금은 근로기준법 제43조에 따라 매월 1회 이상 일정한 날짜에 통화로 직접 근로자에게 그 전액을 지급해야 합니다. 임금은 최저임금법에 따른 최저임금 이상이어야 하며, 사용자는 임금명세서를 근로자에게 교부해야 할 의무가 있습니다 (근로기준법 제48조).</p>
                <p>법정 수당(연장, 야간, 휴일근로수당, 주휴수당 등)은 기본급과 별도로 가산하여 지급됩니다.</p>
            </div>
        </section>

        <!-- Social Insurance Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">🏥</span> 제8조 (사회보험)
            </h2>
            <p class="text-gray-700 leading-relaxed">
                갑과 을은 근로기준법 및 관련 법령에 따라 4대 사회보험 (국민연금, 건강보험, 고용보험, 산재보험)에 가입하며, 보험료는 관계 법령에 따라 갑과 을이 각각 부담한다.
            </p>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 4대 사회보험</p>
                <p>4대 사회보험은 근로자의 생활 안정과 복지 증진을 위한 필수적인 제도입니다. 국민연금, 건강보험, 고용보험은 근로자와 사용자가 보험료를 분담하며, 산재보험은 전액 사용자가 부담합니다. 각 보험의 가입 및 보험료 납부는 법적 의무 사항입니다.</p>
            </div>
        </section>

        <!-- Termination of Employment Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">👋</span> 제9조 (계약 해지)
            </h2>
            <p class="text-gray-700 leading-relaxed">
                본 계약은 다음 각 호의 사유 발생 시 해지될 수 있다.
            </p>
            <ul class="list-disc list-inside ml-4 text-gray-700">
                <li>근로계약 기간이 만료된 경우 (기간의 정함이 있는 경우)</li>
                <li>갑 또는 을이 본 계약 내용을 위반한 경우</li>
                <li>근로기준법 및 기타 관련 법령에 의거한 해고 또는 사직 사유가 발생한 경우</li>
                <li>기타 상호 합의에 의한 경우</li>
            </ul>
            <div class="note mt-6">
                <p class="font-semibold mb-2">⚠️ 유의사항: 계약 해지 및 해고</p>
                <p>사용자는 근로자를 정당한 이유 없이 해고할 수 없습니다 (근로기준법 제23조). 해고 시에는 적어도 30일 전에 예고해야 하며, 30일 전에 예고하지 아니하였을 때에는 30일분 이상의 통상임금을 지급해야 합니다 (해고예고수당, 근로기준법 제26조).</p>
                <p>근로자가 퇴직할 경우에도 회사에 충분한 인수인계 기간을 제공하기 위해 사직 의사를 미리 통보하는 것이 바람직합니다. 퇴직금은 1년 이상 계속 근로한 근로자에게 지급됩니다 (근로자퇴직급여 보장법 제8조).</p>
            </div>
        </section>

        <!-- Other Conditions Section -->
        <section class="mb-8">
            <h2 class="section-title">
                <span class="icon">📝</span> 제10조 (기타 사항)
            </h2>
            <ul class="list-disc list-inside ml-4 text-gray-700">
                <li>본 계약서에 명시되지 않은 사항은 근로기준법 및 회사의 취업규칙에 따른다.</li>
                <li>을은 회사의 영업 비밀 및 기밀 사항을 외부에 누설하지 아니하며, 퇴직 후에도 이를 준수한다.</li>
                <li>본 계약은 ${form.contractCopies || 2}부를 작성하여 갑과 을이 각각 1부씩 보관한다.</li>
            </ul>
            <div class="note mt-6">
                <p class="font-semibold mb-2">💡 중요 안내: 취업규칙 및 비밀유지 의무</p>
                <p>취업규칙은 근로기준법 제93조에 따라 상시 10명 이상의 근로자를 사용하는 사용자가 작성하여 고용노동부장관에게 신고해야 하는 규칙으로, 근로조건에 대한 세부적인 사항을 정합니다. 근로계약서에 명시되지 않은 사항은 취업규칙을 따릅니다.</p>
                <p>영업 비밀 및 기밀 유지 의무는 근로자의 중요한 의무 중 하나입니다. 이는 「부정경쟁방지 및 영업비밀보호에 관한 법률」에 의해 보호되며, 위반 시 법적 책임을 질 수 있습니다.</p>
            </div>
        </section>

        <!-- Signature Section -->
        <section class="mt-12 text-center">
            <h2 class="section-title justify-center">
                <span class="icon">✍️</span> 계약 당사자 서명
            </h2>
            <p class="text-gray-600 mb-8">
                본 계약의 내용을 충분히 이해하고 동의하며, 상호 성실히 이행할 것을 약속합니다.
            </p>

            <div class="flex flex-col md:flex-row justify-around items-center space-y-8 md:space-y-0 md:space-x-12">
                <div class="w-full md:w-1/2 p-6 bg-white rounded-xl shadow-lg border border-gray-200">
                    <p class="text-xl font-bold text-blue-700 mb-4">갑 (사용자)</p>
                    <p class="text-lg text-gray-800"><strong>회사명:</strong> ${form.storeName || '[회사명]'}</p>
                    <p class="text-lg text-gray-800 mb-6"><strong>대표자:</strong> ${form.owner || '[대표자명]'} (인)</p>
                    <div class="border-t-2 border-dashed border-gray-300 pt-4 text-gray-500 text-sm">
                        서명 또는 날인
                    </div>
                </div>

                <div class="w-full md:w-1/2 p-6 bg-white rounded-xl shadow-lg border border-gray-200">
                    <p class="text-xl font-bold text-green-700 mb-4">을 (근로자)</p>
                    <p class="text-lg text-gray-800"><strong>성명:</strong> ${form.name || '[근로자명]'}</p>
                    <p class="text-lg text-gray-800"><strong>생년월일:</strong> ${form.birth || '[YYYY년 MM월 DD일]'}</p>
                    <p class="text-lg text-gray-800 mb-6"><strong>연락처:</strong> ${form.contact || '[휴대폰 번호]'}</p>
                    <div class="border-t-2 border-dashed border-gray-300 pt-4 text-gray-500 text-sm">
                        서명 또는 날인
                    </div>
                </div>
            </div>

            <p class="mt-12 text-gray-500 text-sm">
                계약 체결일: ${contractDate}
            </p>
        </section>

        <!-- Footer / Legal Disclaimer -->
        <footer class="mt-16 text-center text-gray-500 text-xs">
            <p>본 계약서는 근로기준법을 바탕으로 작성된 표준 양식이며, 개별 상황에 따라 추가 또는 수정이 필요할 수 있습니다.</p>
            <p>법률 전문가와 상담하여 최종 내용을 확정하시길 권장합니다.</p>
        </footer>
    </div>

    <!-- Print Button -->
    <div class="no-print fixed bottom-4 right-4">
        <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg shadow-lg font-semibold transition-colors">
            🖨️ 인쇄하기
        </button>
    </div>
</body>
</html>`;

    // 파일명 생성 (근로자명_날짜_시간)
    const workerName = form.name || '근로자';
    const today = new Date();
    const dateStr = today.getFullYear().toString().slice(-2) + 
                   String(today.getMonth() + 1).padStart(2, '0') + 
                   String(today.getDate()).padStart(2, '0');
    const timeStr = String(today.getHours()).padStart(2, '0') + 
                   String(today.getMinutes()).padStart(2, '0');
    const fileName = `근로계약서_${workerName}_${dateStr}_${timeStr}.html`;

    // HTML 파일을 Blob으로 생성하고 다운로드
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    // 다운로드 후 새 창에서 바로 열기
    window.open(url, '_blank');
    URL.revokeObjectURL(url);
  };

  // 각 단계별 입력 폼
  const renderStep = () => {
    // 시급제 계산을 위한 변수들 (renderStep 함수 시작 부분에서 정의)
    const workStats3 = calcWorkStats(form);
    const hourlyWage = Number(form.hourlyWage) || 0;
    const allowances = Number(form.allowances) || 0;
    
    // 시급제 계산
    let calculatedMonthlySalary = 0, overtimePay = 0, nightPay = 0, monthlyHolidayPay = 0, totalCalculatedSalary = 0;
    let basePay = 0, totalPay = 0, monthlyWorkHours = 0, overtimeHours = 0, nightHours = 0, weeklyOvertime = 0;
    
    if (form.salaryType === 'hourly' && hourlyWage > 0) {
      monthlyWorkHours = workStats3.totalMonth;
      const weeklyWorkHours = workStats3.totalWeek;
      
      calculatedMonthlySalary = hourlyWage * (monthlyWorkHours / 60);
      overtimeHours = workStats3.over;
      overtimePay = hourlyWage * 0.5 * (overtimeHours / 60);
      nightHours = workStats3.night;
      nightPay = hourlyWage * 0.5 * (nightHours / 60);
      
      weeklyOvertime = Math.max(0, weeklyWorkHours - 40);
      const weeklyHolidayPay = hourlyWage * (weeklyOvertime / 60);
      monthlyHolidayPay = weeklyHolidayPay * 4.345;
      
      totalCalculatedSalary = calculatedMonthlySalary + overtimePay + nightPay + monthlyHolidayPay + allowances;
    }
    
    basePay = Number(form.baseSalary) || 0;
    totalPay = basePay + allowances;
    
    switch (step) {
      case 0: // 사업장 정보
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">사업장 정보를 입력해주세요</h2>
              <p className="step-description">근로계약서에 필요한 사업장 기본 정보입니다</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">사업장의 정확한 정보를 입력해주세요. 이 정보는 근로계약서의 당사자 정보로 사용되며, 법적 분쟁 시 중요한 근거가 됩니다.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 실무 팁</p>
                <p className="guide-tip-text">• 사업장명은 사업자등록증에 기재된 명칭과 일치해야 합니다<br/>• 대표자명은 법인등기부등본 또는 사업자등록증을 확인하세요<br/>• 주소는 도로명주소를 사용하는 것이 좋습니다</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">사업장명</label>
              <input 
                name="storeName" 
                value={form.storeName} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: OO카페, OO식당" 
              />
              <p className="form-help">사업장의 정식 명칭을 입력해주세요</p>
            </div>

            <div className="form-group">
              <label className="form-label">대표자명</label>
              <input 
                name="owner" 
                value={form.owner} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="대표자 성명" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">사업장 주소</label>
              <div className="address-input-group">
                <input 
                  name="address" 
                  value={form.address} 
                  onChange={handleChange} 
                  className="form-input address-main" 
                  placeholder="도로명 주소" 
                />
                <button 
                  type="button" 
                  onClick={handleAddressSearch} 
                  className="address-search-btn"
                >
                  주소찾기
                </button>
              </div>
              <input 
                name="addressDetail" 
                value={form.addressDetail} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="상세주소 (건물명, 층수 등)" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">사업장 연락처</label>
              <input 
                name="storeContact" 
                value={form.storeContact} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="02-0000-0000" 
              />
            </div>
          </div>
        );

      case 1: // 근로자 정보
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근로자 정보를 입력해주세요</h2>
              <p className="step-description">계약을 체결할 근로자의 기본 정보입니다</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">근로자의 개인정보를 정확히 입력해주세요. 주민등록상의 정보와 일치해야 하며, 개인정보보호법에 따라 안전하게 관리됩니다.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 법적 요건</p>
                <p className="guide-tip-text">• 근로기준법 제17조: 근로계약서에는 근로자의 성명이 포함되어야 합니다<br/>• 만 18세 미만자는 보호자 동의가 필요할 수 있습니다<br/>• 주민등록번호는 선택사항이며, 생년월일만으로도 충분합니다</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">근로자 성명</label>
              <input 
                name="name" 
                value={form.name} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="성명" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">생년월일</label>
              <input 
                name="birth" 
                type="date" 
                value={form.birth} 
                onChange={handleChange} 
                className="form-input" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">근로자 주소</label>
              <div className="address-input-group">
                <input 
                  name="workerAddress" 
                  value={form.workerAddress} 
                  onChange={handleChange} 
                  className="form-input address-main" 
                  placeholder="도로명 주소" 
                />
                <button 
                  type="button" 
                  onClick={() => {
                    if (window.daum && window.daum.Postcode) {
                      new window.daum.Postcode({
                        oncomplete: function(data) {
                          setForm(prev => ({
                            ...prev,
                            workerAddress: data.address,
                            workerAddressDetail: ''
                          }));
                        }
                      }).open();
                    } else {
                      alert('주소 검색 서비스를 불러오는 중입니다. 잠시 후 다시 시도해주세요.');
                    }
                  }} 
                  className="address-search-btn"
                >
                  주소찾기
                </button>
              </div>
              <input 
                name="workerAddressDetail" 
                value={form.workerAddressDetail} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="상세주소 (건물명, 층수 등)" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">연락처</label>
              <input 
                name="contact" 
                value={form.contact} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="010-0000-0000" 
              />
              <p className="form-help">휴대폰 번호를 입력해주세요</p>
            </div>
          </div>
        );

      case 2: // 계약 기간
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">계약 기간을 설정해주세요</h2>
              <p className="step-description">계약의 시작일과 종료일을 입력해주세요</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">근로계약의 기간을 명확히 설정해주세요. 기간제 계약과 무기한 계약의 법적 효과가 다르므로 신중히 결정하세요.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 법적 기준</p>
                <p className="guide-tip-text">• 기간제 근로자 보호법: 2년 초과 기간제 계약은 무기한 계약으로 전환<br/>• 수습기간은 최대 3개월까지 가능 (근로기준법 제26조)<br/>• 계약 종료일을 비워두면 무기한 계약이 됩니다</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">계약 시작일</label>
              <input 
                name="periodStart" 
                type="date" 
                value={form.periodStart} 
                onChange={handleChange} 
                className="form-input" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">계약 종료일</label>
              <input 
                name="periodEnd" 
                type="date" 
                value={form.periodEnd} 
                onChange={handleChange} 
                className="form-input" 
              />
              <p className="form-help">기간제 계약의 경우 종료일을, 무기한 계약의 경우 비워두세요</p>
            </div>

            <div className="form-group">
              <label className="form-label">수습 기간</label>
              <select 
                name="probationPeriod" 
                value={form.probationPeriod} 
                onChange={handleChange} 
                className="form-input"
              >
                <option value="">수습 기간 없음</option>
                <option value="1개월">1개월</option>
                <option value="2개월">2개월</option>
                <option value="3개월">3개월</option>
              </select>
              <p className="form-help">수습 기간 중 급여는 최저임금의 90% 이상 지급 가능합니다</p>
            </div>
          </div>
        );

      case 3: // 근무 조건
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근무 조건을 설정해주세요</h2>
              <p className="step-description">근무 장소와 업무 내용을 입력해주세요</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">근무 장소와 업무 내용을 구체적으로 명시해주세요. 이는 근로자의 권리와 의무를 명확히 하고, 향후 업무 범위 변경 시 참고 자료가 됩니다.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 실무 가이드</p>
                <p className="guide-tip-text">• 근무장소는 구체적인 주소나 건물명을 명시하세요<br/>• 업무내용은 담당 업무의 핵심을 간단명료하게 작성하세요<br/>• 직책은 회사 내 조직도에 맞는 명칭을 사용하세요</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">근무 장소</label>
              <input 
                name="workLocation" 
                value={form.workLocation} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="근무할 장소 (예: 본사, 지점 등)" 
              />
              <p className="form-help">기본적으로 사업장 주소와 동일하지만, 별도 지정 장소가 있다면 입력해주세요</p>
            </div>

            <div className="form-group">
              <label className="form-label">업무 내용</label>
              <input 
                name="jobDesc" 
                value={form.jobDesc} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 웹 개발, 영업, 사무 지원, 주방 보조 등" 
              />
              <p className="form-help">담당할 업무를 구체적으로 입력해주세요</p>
            </div>

            <div className="form-group">
              <label className="form-label">직위/직책</label>
              <input 
                name="position" 
                value={form.position} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 사원, 대리, 과장, 주임 등" 
              />
            </div>
          </div>
        );

      case 4: // 근로시간
        const workStatsBtn = calcWorkStats(form);
        const getBtnTime = (day) => {
          const mins = form.workTimeType === 'same'
            ? (() => {
                if (!form.commonStart || !form.commonEnd) return 0;
                const s = getMinutes(form.commonStart);
                const e = getMinutes(form.commonEnd);
                const br = Number(form.commonBreak) || 0;
                let work = e > s ? e - s : (e + 24 * 60) - s;
                return Math.max(0, work - br);
              })()
            : (form.dayTimes[day]?.start && form.dayTimes[day]?.end ? workStatsBtn.dayStats[day]?.work || 0 : 0);
          const h = Math.floor(mins / 60);
          const m = mins % 60;
          return mins > 0 ? `${h}H${m ? m + 'M' : ''}` : '';
        };

        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근로시간을 설정해주세요</h2>
              <p className="step-description">출퇴근 시간이 매일 같나요, 요일마다 다르나요?</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">근로시간은 근로기준법의 핵심 규정입니다. 법정 근로시간을 준수하고, 연장근로와 휴게시간을 정확히 설정해주세요.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 법적 기준</p>
                <p className="guide-tip-text">• 1일 8시간, 1주 40시간이 기본 근로시간입니다<br/>• 1일 8시간 초과는 연장근로로 50% 가산 지급<br/>• 22:00~06:00 근무는 야간근로로 50% 가산 지급<br/>• 4시간 이상 근무 시 30분, 8시간 이상 시 1시간 휴게 필수</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">근무 요일</label>
              <div className="day-selector">
                {daysOfWeek.map((day) => (
                  <label key={day} className={`day-option ${form.days.includes(day) ? 'selected' : ''}`}>
                    <input
                      type="checkbox"
                      name="days"
                      value={day}
                      checked={form.days.includes(day)}
                      onChange={handleChange}
                      className="day-checkbox"
                    />
                    <span className="day-text">{day}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="form-group">
              <div className="time-type-selector">
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, workTimeType: 'same', dayTimes: {} }))} 
                  className={`time-type-btn ${form.workTimeType === 'same' ? 'active' : ''}`}
                >
                  매일 같다
                </button>
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, workTimeType: 'diff', commonStart: '', commonEnd: '', commonBreak: '' }))} 
                  className={`time-type-btn ${form.workTimeType === 'diff' ? 'active' : ''}`}
                >
                  요일마다 다르다
                </button>
              </div>
            </div>

            {form.workTimeType === 'same' && (
              <>
                <div className="form-group">
                  <label className="form-label">출근 시간</label>
                  <input 
                    name="commonStart" 
                    type="time" 
                    value={form.commonStart} 
                    onChange={handleChange} 
                    className="form-input" 
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">퇴근 시간</label>
                  <input 
                    name="commonEnd" 
                    type="time" 
                    value={form.commonEnd} 
                    onChange={handleChange} 
                    className="form-input" 
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">휴게시간 (분)</label>
                  <input 
                    name="commonBreak" 
                    type="number" 
                    value={form.commonBreak} 
                    onChange={handleChange} 
                    className="form-input" 
                    min={0} 
                    placeholder="60" 
                  />
                </div>
              </>
            )}

            {form.workTimeType === 'diff' && (
              <div className="form-group">
                <label className="form-label">요일별 근무시간</label>
                <div className="day-times">
                  {form.days.map((day) => (
                    <div key={day} className="day-time-item">
                      <div className="day-time-header">
                        <span className="day-time-day">{day}</span>
                        <span className="day-time-summary">{getBtnTime(day)}</span>
                      </div>
                      <div className="day-time-inputs">
                        <input
                          type="time"
                          name="dayStart"
                          data-day={day}
                          value={form.dayTimes[day]?.start || ''}
                          onChange={handleChange}
                          className="form-input time-input"
                          placeholder="출근"
                        />
                        <span className="time-separator">~</span>
                        <input
                          type="time"
                          name="dayEnd"
                          data-day={day}
                          value={form.dayTimes[day]?.end || ''}
                          onChange={handleChange}
                          className="form-input time-input"
                          placeholder="퇴근"
                        />
                        <input
                          type="number"
                          name="dayBreak"
                          data-day={day}
                          value={form.dayTimes[day]?.break || ''}
                          onChange={handleChange}
                          className="form-input break-input"
                          min={0}
                          placeholder="휴게(분)"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {form.workTimeType && (
              <div className="work-summary">
                <WorkTimeSummary form={form} />
              </div>
            )}
          </div>
        );

      case 5: // 임금 조건
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">임금 조건을 설정해주세요</h2>
              <p className="step-description">근로자의 임금 조건을 설정해주세요</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">임금은 근로계약의 핵심 조건입니다. 최저임금을 준수하고, 시급제의 경우 모든 수당을 포함한 정확한 계산이 필요합니다.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 법적 기준</p>
                <p className="guide-tip-text">• 2024년 최저임금: 9,860원/시간 (월 2,060,580원)<br/>• 시급제: 기본급 + 연장수당(50%) + 야간수당(50%) + 주휴수당<br/>• 임금은 매월 정기적으로 지급해야 합니다 (근로기준법 제43조)<br/>• 제수당은 기본급과 별도로 지급 가능합니다</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">임금 지급 방식</label>
              <div className="time-type-selector">
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, salaryType: 'monthly' }))} 
                  className={`time-type-btn ${form.salaryType === 'monthly' ? 'active' : ''}`}
                >
                  월급제
                </button>
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, salaryType: 'hourly' }))} 
                  className={`time-type-btn ${form.salaryType === 'hourly' ? 'active' : ''}`}
                >
                  시급제
                </button>
              </div>
            </div>

            {form.salaryType === 'monthly' ? (
              <div className="form-group">
                <label className="form-label">월 기본급 (원)</label>
                <input 
                  name="baseSalary" 
                  type="number" 
                  value={form.baseSalary} 
                  onChange={handleChange} 
                  className="form-input" 
                  placeholder="3000000" 
                />
                <p className="form-help">2024년 최저임금: 월 2,060,580원 (시급 9,860원 기준)</p>
              </div>
            ) : (
              <div className="form-group">
                <label className="form-label">시급 (원)</label>
                <input 
                  name="hourlyWage" 
                  type="number" 
                  value={form.hourlyWage} 
                  onChange={handleChange} 
                  className="form-input" 
                  placeholder="9860" 
                />
                <p className="form-help">2024년 최저임금: 9,860원/시간</p>
              </div>
            )}

            <div className="form-group">
              <label className="form-label">제수당 (원)</label>
              <input 
                name="allowances" 
                type="number" 
                value={form.allowances} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="식대, 교통비, 직책수당 등" 
              />
              <p className="form-help">식대, 교통비, 직책수당 등을 포함한 제수당</p>
            </div>

            <div className="form-group">
              <label className="form-label">임금 지급일</label>
              <select 
                name="payday" 
                value={form.payday} 
                onChange={handleChange} 
                className="form-input"
              >
                <option value="">선택해주세요</option>
                <option value="매월 25일">매월 25일</option>
                <option value="매월 말일">매월 말일</option>
                <option value="매월 10일">매월 10일</option>
                <option value="매월 15일">매월 15일</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">지급 방법</label>
              <select 
                name="paymentMethod" 
                value={form.paymentMethod} 
                onChange={handleChange} 
                className="form-input"
              >
                <option value="계좌이체">계좌이체</option>
                <option value="현금">현금</option>
                <option value="수표">수표</option>
              </select>
            </div>

            {((form.salaryType === 'monthly' && basePay > 0) || (form.salaryType === 'hourly' && hourlyWage > 0)) && (
              <div className="salary-preview">
                <h3 className="salary-preview-title">임금 미리보기</h3>
                <div className="salary-preview-content">
                  {form.salaryType === 'monthly' ? (
                    <>
                      <div className="salary-item">
                        <span className="salary-label">월 기본급:</span>
                        <span className="salary-value">{basePay.toLocaleString()}원</span>
                      </div>
                      <div className="salary-item">
                        <span className="salary-label">제수당:</span>
                        <span className="salary-value">{allowances.toLocaleString()}원</span>
                      </div>
                      <div className="salary-item">
                        <span className="salary-label">총 월 임금:</span>
                        <span className="salary-value">{totalPay.toLocaleString()}원</span>
                      </div>
                    </>
                                     ) : (
                     <>
                       <div className="salary-item">
                         <span className="salary-label">시급:</span>
                         <span className="salary-value">{hourlyWage.toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">월 기본급 (${Math.round(monthlyWorkHours / 60)}시간):</span>
                         <span className="salary-value">{Math.round(calculatedMonthlySalary).toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">연장근로수당 (${Math.round(overtimeHours / 60)}시간, 50%):</span>
                         <span className="salary-value">{Math.round(overtimePay).toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">야간근로수당 (${Math.round(nightHours / 60)}시간, 50%):</span>
                         <span className="salary-value">{Math.round(nightPay).toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">주휴수당 (${Math.round(monthlyHolidayPay).toLocaleString()}원):</span>
                         <span className="salary-value">{Math.round(monthlyHolidayPay).toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">제수당:</span>
                         <span className="salary-value">{allowances.toLocaleString()}원</span>
                       </div>
                       <div className="salary-item">
                         <span className="salary-label">총 월 예상 임금:</span>
                         <span className="salary-value">{Math.round(totalCalculatedSalary).toLocaleString()}원</span>
                       </div>
                       <div className="salary-formula">
                         <p className="formula-title">📊 계산 공식</p>
                         <p className="formula-text">
                           기본급({hourlyWage.toLocaleString()}원 × {Math.round(monthlyWorkHours / 60)}시간) + 
                           연장수당({hourlyWage.toLocaleString()}원 × 0.5 × {Math.round(overtimeHours / 60)}시간) + 
                           야간수당({hourlyWage.toLocaleString()}원 × 0.5 × {Math.round(nightHours / 60)}시간) + 
                           주휴수당({hourlyWage.toLocaleString()}원 × {Math.round(weeklyOvertime / 60)}시간 × 4.345주) + 
                           제수당({allowances.toLocaleString()}원)
                         </p>
                       </div>
                     </>
                   )}
                  <div className="salary-item">
                    <span className="salary-label">야간근로시간:</span>
                    <span className="salary-value">{getHourStr(workStats3.night)}</span>
                  </div>
                  <div className="salary-item">
                    <span className="salary-label">연장근로시간:</span>
                    <span className="salary-value">{getHourStr(workStats3.over)}</span>
                  </div>
                </div>
                <p className="salary-note">※ 이 정보는 참고용이며, 계약서에는 포함되지 않습니다.</p>
              </div>
            )}
          </div>
        );

      case 6: // 기타 사항
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">기타 사항을 설정해주세요</h2>
              <p className="step-description">계약의 마지막 세부사항입니다</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 작성 가이드</p>
              <p className="guide-text">계약의 마지막 단계입니다. 사회보험 가입, 계약 해지 조건, 기밀유지 등 중요한 사항들을 확인해주세요.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 법적 의무</p>
                <p className="guide-tip-text">• 4대 사회보험은 근로자 1명 이상 시 의무 가입<br/>• 계약 해지 조건은 구체적이고 합리적으로 작성<br/>• 기밀유지 의무는 업무상 비밀에 한정되어야 함<br/>• 계약서는 근로자와 사용자 각각 1부씩 보관</p>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label checkbox-label">
                <input 
                  type="checkbox" 
                  name="socialInsurance" 
                  checked={form.socialInsurance} 
                  onChange={handleChange} 
                  className="form-checkbox"
                />
                <span>4대 사회보험 가입</span>
              </label>
              <p className="form-help">국민연금, 건강보험, 고용보험, 산재보험 가입</p>
            </div>

            <div className="form-group">
              <label className="form-label">계약 해지 조건</label>
              <textarea 
                name="termination" 
                value={form.termination} 
                onChange={handleChange} 
                className="form-textarea" 
                placeholder="예: 1개월 전 서면 통지, 정당한 사유가 있는 경우 등" 
                rows="3"
              />
            </div>

            <div className="form-group">
              <label className="form-label checkbox-label">
                <input 
                  type="checkbox" 
                  name="confidentiality" 
                  checked={form.confidentiality} 
                  onChange={handleChange} 
                  className="form-checkbox"
                />
                <span>영업비밀 및 기밀 유지 의무</span>
              </label>
              <p className="form-help">회사의 영업비밀 및 기밀사항을 외부에 누설하지 않음</p>
            </div>

            <div className="form-group">
              <label className="form-label">계약서 작성 부수</label>
              <select 
                name="contractCopies" 
                value={form.contractCopies} 
                onChange={handleChange} 
                className="form-input"
              >
                <option value="2">2부 (갑, 을 각 1부)</option>
                <option value="3">3부 (갑, 을, 보관용)</option>
              </select>
            </div>
          </div>
        );

      case 7: // 최종 확인
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">입력 내용 최종 확인</h2>
              <p className="step-description">작성한 내용을 확인하고 PDF로 저장하세요</p>
            </div>
            
            <div className="guide-box">
              <p className="guide-title">📋 최종 확인 가이드</p>
              <p className="guide-text">모든 정보가 정확한지 확인해주세요. 계약서는 법적 효력이 있으므로 신중하게 검토하시기 바랍니다.</p>
              <div className="guide-tip">
                <p className="guide-tip-title">💡 체크리스트</p>
                <p className="guide-tip-text">• 모든 필수 정보가 입력되었는지 확인<br/>• 임금 계산이 정확한지 확인<br/>• 근로시간이 법정 기준을 준수하는지 확인<br/>• 계약서를 다운로드 후 양쪽이 서명하여 보관</p>
              </div>
            </div>
            
            <div className="final-preview">
              <div className="preview-section">
                <h3 className="preview-section-title">📄 사업장 정보</h3>
                <div className="preview-content">
                  <div className="preview-item">
                    <span className="preview-label">사업장명:</span>
                    <span className="preview-value">{form.storeName || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">대표자:</span>
                    <span className="preview-value">{form.owner || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">주소:</span>
                    <span className="preview-value">{form.address || '-'} {form.addressDetail || ''}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">연락처:</span>
                    <span className="preview-value">{form.storeContact || '-'}</span>
                  </div>
                </div>
              </div>

              <div className="preview-section">
                <h3 className="preview-section-title">👤 근로자 정보</h3>
                <div className="preview-content">
                  <div className="preview-item">
                    <span className="preview-label">성명:</span>
                    <span className="preview-value">{form.name || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">생년월일:</span>
                    <span className="preview-value">{form.birth || '-'}</span>
                  </div>
                                     <div className="preview-item">
                     <span className="preview-label">주소:</span>
                     <span className="preview-value">{form.workerAddress || '-'} {form.workerAddressDetail || ''}</span>
                   </div>
                  <div className="preview-item">
                    <span className="preview-label">연락처:</span>
                    <span className="preview-value">{form.contact || '-'}</span>
                  </div>
                </div>
              </div>

              <div className="preview-section">
                <h3 className="preview-section-title">📅 계약 기간</h3>
                <div className="preview-content">
                  <div className="preview-item">
                    <span className="preview-label">계약 시작일:</span>
                    <span className="preview-value">{form.periodStart || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">계약 종료일:</span>
                    <span className="preview-value">{form.periodEnd || '무기한'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">수습 기간:</span>
                    <span className="preview-value">{form.probationPeriod || '없음'}</span>
                  </div>
                </div>
              </div>

              <div className="preview-section">
                <h3 className="preview-section-title">📍 근무 조건</h3>
                <div className="preview-content">
                  <div className="preview-item">
                    <span className="preview-label">근무 장소:</span>
                    <span className="preview-value">{form.workLocation || form.address || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">업무 내용:</span>
                    <span className="preview-value">{form.jobDesc || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">직위/직책:</span>
                    <span className="preview-value">{form.position || '-'}</span>
                  </div>
                </div>
              </div>

              <div className="preview-section">
                <h3 className="preview-section-title">⏰ 근로시간</h3>
                <div className="preview-content">
                  <div className="preview-item">
                    <span className="preview-label">근무 요일:</span>
                    <span className="preview-value">{form.days.length > 0 ? form.days.join(', ') : '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">근무시간:</span>
                    <span className="preview-value">
                      {form.workTimeType === 'same' 
                        ? `${form.commonStart || '-'} ~ ${form.commonEnd || '-'} (휴게: ${form.commonBreak || 0}분)`
                        : '요일별 상이'
                      }
                    </span>
                  </div>
                </div>
              </div>

              <div className="preview-section">
                <h3 className="preview-section-title">💰 임금 조건</h3>
                <div className="preview-content">
                  {form.salaryType === 'monthly' ? (
                    <>
                      <div className="preview-item">
                        <span className="preview-label">임금 방식:</span>
                        <span className="preview-value">월급제</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">월 기본급:</span>
                        <span className="preview-value">{form.baseSalary ? `${Number(form.baseSalary).toLocaleString()}원` : '-'}</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">제수당:</span>
                        <span className="preview-value">{form.allowances ? `${Number(form.allowances).toLocaleString()}원` : '-'}</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">총 월 임금:</span>
                        <span className="preview-value">
                          {form.baseSalary && form.allowances 
                            ? `${(Number(form.baseSalary) + Number(form.allowances)).toLocaleString()}원`
                            : '-'
                          }
                        </span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="preview-item">
                        <span className="preview-label">임금 방식:</span>
                        <span className="preview-value">시급제</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">시급:</span>
                        <span className="preview-value">{form.hourlyWage ? `${Number(form.hourlyWage).toLocaleString()}원/시간` : '-'}</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">월 기본급:</span>
                        <span className="preview-value">{Math.round(calculatedMonthlySalary).toLocaleString()}원</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">연장근로수당:</span>
                        <span className="preview-value">{Math.round(overtimePay).toLocaleString()}원</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">야간근로수당:</span>
                        <span className="preview-value">{Math.round(nightPay).toLocaleString()}원</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">주휴수당:</span>
                        <span className="preview-value">{Math.round(monthlyHolidayPay).toLocaleString()}원</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">제수당:</span>
                        <span className="preview-value">{form.allowances ? `${Number(form.allowances).toLocaleString()}원` : '-'}</span>
                      </div>
                      <div className="preview-item">
                        <span className="preview-label">총 월 예상 임금:</span>
                        <span className="preview-value">{Math.round(totalCalculatedSalary).toLocaleString()}원</span>
                      </div>
                    </>
                  )}
                  <div className="preview-item">
                    <span className="preview-label">임금 지급일:</span>
                    <span className="preview-value">{form.payday || '-'}</span>
                  </div>
                  <div className="preview-item">
                    <span className="preview-label">지급 방법:</span>
                    <span className="preview-value">{form.paymentMethod || '-'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="preview-actions">
              <button 
                onClick={handleSavePDF} 
                className="save-pdf-btn"
              >
                📄 표준근로계약서 HTML 다운로드
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="contract-form-page">
      <div className="contract-form-container">
        {/* Header */}
        <div className="form-header">
          <button onClick={() => navigate('/')} className="back-btn">
            ← 홈으로
          </button>
          <h1 className="form-title">표준근로계약서 작성</h1>
          <div className="header-spacer"></div>
        </div>
        
        {/* Progress Bar */}
        <div className="progress-container">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${((step + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
          <div className="progress-text">
            {step + 1} / {steps.length}
          </div>
        </div>

        {/* Step Indicator */}
        <div className="step-indicator">
          {steps.map((stepName, index) => (
            <div key={index} className={`step-dot ${index <= step ? 'active' : ''} ${index === step ? 'current' : ''}`}>
              <span className="step-number">{index + 1}</span>
              <span className="step-name">{stepName}</span>
            </div>
          ))}
        </div>
        
        {/* Step Content */}
        <div className="step-content">
          {renderStep()}
        </div>
        
        {/* Navigation Buttons */}
        <div className="navigation-buttons">
          <button 
            onClick={() => setStep(Math.max(0, step - 1))} 
            className={`nav-btn prev-btn ${step === 0 ? 'hidden' : ''}`}
          >
            ← 이전
          </button>
          <button 
            onClick={() => setStep(Math.min(steps.length - 1, step + 1))} 
            className={`nav-btn next-btn ${step === steps.length - 1 ? 'hidden' : ''}`}
          >
            다음 →
          </button>
        </div>
      </div>
    </div>
  );
}

// 근무시간 안내 컴포넌트 분리
function WorkTimeSummary({ form }) {
  const workStats = calcWorkStats(form);
  return (
    <div className="work-time-summary">
      <h3 className="summary-title">근무시간 요약</h3>
      <div className="summary-content">
        <div className="summary-item">
          <span className="summary-label">주당 근무시간:</span>
          <span className="summary-value">{getHourStr(workStats.totalWeek)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">월간 근무시간(예상):</span>
          <span className="summary-value">{getHourStr(workStats.totalMonth)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">야간근로(22:00~06:00):</span>
          <span className="summary-value">{getHourStr(workStats.night)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">연장근로(1일 8시간 초과):</span>
          <span className="summary-value">{getHourStr(workStats.over)}</span>
        </div>
      </div>
      <p className="summary-note">※ 월평균 4.345주 기준으로 계산됩니다</p>
    </div>
  );
}

export default ContractForm; 