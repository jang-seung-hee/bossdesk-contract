import React from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import './App.css';
import ContractForm from './ContractForm';

function Home() {
  const navigate = useNavigate();
  
  return (
    <div className="home-container">
      <div className="home-content">
        {/* Hero Section */}
        <div className="hero-section">
          <div className="logo-container">
            <div className="logo-icon">
              <svg viewBox="0 0 24 24" fill="none" className="logo-svg">
                <path d="M3 3h18v18H3V3z" stroke="currentColor" strokeWidth="2" fill="none"/>
                <path d="M7 7h10v2H7V7z" fill="currentColor"/>
                <path d="M7 11h10v2H7v-2z" fill="currentColor"/>
                <path d="M7 15h6v2H7v-2z" fill="currentColor"/>
              </svg>
            </div>
          </div>
          
          <h1 className="hero-title">사장님책상</h1>
          <p className="hero-subtitle">비즈니스를 더 스마트하게</p>
        </div>

        {/* Action Buttons */}
        <div className="action-buttons">
          <button 
            className="action-button primary"
            onClick={() => navigate('/contract')}
          >
            <span className="button-icon">📄</span>
            <span className="button-text">
              <span className="button-title">근로계약서 만들기</span>
              <span className="button-description">법적 안전을 위한 맞춤형 계약서</span>
            </span>
            <span className="button-arrow">→</span>
          </button>
          
          <button 
            className="action-button secondary"
            onClick={() => alert('수당 계산기 기능은 곧 추가됩니다!')}
          >
            <span className="button-icon">💰</span>
            <span className="button-text">
              <span className="button-title">수당 계산기</span>
              <span className="button-description">정확한 임금 계산 도구</span>
            </span>
            <span className="button-arrow">→</span>
          </button>
        </div>

        {/* Footer */}
        <div className="home-footer">
          <p className="footer-text">신뢰할 수 있는 비즈니스 파트너</p>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contract" element={<ContractForm />} />
      </Routes>
    </Router>
  );
}

export default App;
