import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useNavigate } from 'react-router-dom';

const steps = [
  '사업장 정보',
  '근로자 정보', 
  '근무 기간',
  '근무 요일 선택',
  '근무시간 설정',
  '임금 정보',
  '업무 및 기타',
  '미리보기 & 저장',
];



// 시간 계산 유틸
function getMinutes(t) {
  if (!t) return 0;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}
function getHourStr(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}시간${m ? ' ' + m + '분' : ''}`;
}
function calcWorkStats(form) {
  let totalWeek = 0, totalMonth = 0, night = 0, over = 0;
  const dayStats = {};
  const NIGHT_START = 22 * 60, NIGHT_END = 6 * 60; // 22:00~06:00
  form.days.forEach(day => {
    let s, e, br;
    if (form.workTimeType === 'same') {
      s = getMinutes(form.commonStart);
      e = getMinutes(form.commonEnd);
      br = Number(form.commonBreak) || 0;
    } else {
      s = getMinutes(form.dayTimes[day]?.start);
      e = getMinutes(form.dayTimes[day]?.end);
      br = Number(form.dayTimes[day]?.break) || 0;
    }
    if ((!s && !e) || e === s) { dayStats[day] = { work: 0, night: 0, over: 0 }; return; }
    let work = e > s ? e - s : (e + 24 * 60) - s;
    work = Math.max(0, work - br); // 휴게시간 차감
    let nightMin = 0;
    // 야간근로 계산
    for (let t = s; t < s + work + br; t += 10) {
      const cur = t % (24 * 60);
      if (cur >= NIGHT_START || cur < NIGHT_END) nightMin += 10;
    }
    // 연장근로(1일 8시간 초과)
    let overMin = work > 480 ? work - 480 : 0;
    dayStats[day] = { work, night: nightMin, over: overMin };
    totalWeek += work;
    night += nightMin;
    over += overMin;
  });
  totalMonth = Math.round(totalWeek * 4.345); // 월평균 주수
  return { dayStats, totalWeek, totalMonth, night, over };
}

function ContractForm() {
  const [form, setForm] = useState({
    // 사업장 정보
    storeName: '',
    owner: '',
    address: '',
    addressDetail: '',
    // 근로자 정보
    name: '',
    birth: '',
    contact: '',
    // 근무 조건
    periodStart: '',
    periodEnd: '',
    workTimeType: '', // 'same' or 'diff'
    days: [],
    dayTimes: {}, // { '월': {start: '', end: '', break: ''}, ... }
    commonStart: '',
    commonEnd: '',
    commonBreak: '',
    jobDesc: '',
    breakTime: '',
    termination: '',
    wage: '',
    payday: '',
  });
  const [step, setStep] = useState(0);
  const previewRef = useRef(null);
  const daysOfWeek = ['월', '화', '수', '목', '금', '토', '일'];
  const navigate = useNavigate();

  // 카카오 주소 API 스크립트 동적 로드
  React.useEffect(() => {
    if (!window.daum) {
      const script = document.createElement('script');
      script.src = 'https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked, dataset } = e.target;
    if (name === 'days') {
      setForm((prev) => {
        const newDays = checked
          ? [...prev.days, value]
          : prev.days.filter((d) => d !== value);
        // days에서 빠진 요일의 시간 정보도 삭제
        const newDayTimes = { ...prev.dayTimes };
        if (!checked) delete newDayTimes[value];
        return { ...prev, days: newDays, dayTimes: newDayTimes };
      });
    } else if (name === 'dayStart' || name === 'dayEnd' || name === 'dayBreak') {
      const day = dataset.day;
      setForm((prev) => ({
        ...prev,
        dayTimes: {
          ...prev.dayTimes,
          [day]: {
            ...prev.dayTimes[day],
            [name === 'dayStart' ? 'start' : name === 'dayEnd' ? 'end' : 'break']: value
          }
        }
      }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  // 주소 찾기 버튼 클릭 시 카카오 주소 API 호출
  const handleAddressSearch = () => {
    if (!window.daum || !window.daum.Postcode) {
      alert('주소 검색 서비스를 불러오는 중입니다. 잠시 후 다시 시도해 주세요.');
      return;
    }
    new window.daum.Postcode({
      oncomplete: function(data) {
        setForm((prev) => ({ ...prev, address: data.address }));
      }
    }).open();
  };

  const handleSavePDF = async () => {
    if (!previewRef.current) return;
    const canvas = await html2canvas(previewRef.current);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgProps = canvas.width / canvas.height;
    let pdfWidth = pageWidth - 40;
    let pdfHeight = pdfWidth / imgProps;
    if (pdfHeight > pageHeight - 40) {
      pdfHeight = pageHeight - 40;
      pdfWidth = pdfHeight * imgProps;
    }
    pdf.addImage(imgData, 'PNG', (pageWidth - pdfWidth) / 2, 20, pdfWidth, pdfHeight);
    pdf.save('근로계약서.pdf');
  };



  // 각 단계별 입력 폼
  const renderStep = () => {
    switch (step) {
      case 0: // 사업장 정보
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">사업장 정보를 입력해주세요</h2>
              <p className="step-description">근로계약서에 필요한 사업장 기본 정보입니다</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">사업장명</label>
              <input 
                name="storeName" 
                value={form.storeName} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: OO카페, OO식당" 
              />
              <p className="form-help">사업장의 정식 명칭을 입력해주세요</p>
            </div>

            <div className="form-group">
              <label className="form-label">대표자명</label>
              <input 
                name="owner" 
                value={form.owner} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="대표자 성명" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">사업장 주소</label>
              <div className="address-input-group">
                <input 
                  name="address" 
                  value={form.address} 
                  onChange={handleChange} 
                  className="form-input address-main" 
                  placeholder="도로명 주소" 
                />
                <button 
                  type="button" 
                  onClick={handleAddressSearch} 
                  className="address-search-btn"
                >
                  주소찾기
                </button>
              </div>
              <input 
                name="addressDetail" 
                value={form.addressDetail} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="상세주소 (건물명, 층수 등)" 
              />
            </div>
          </div>
        );

      case 1: // 근로자 정보
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근로자 정보를 입력해주세요</h2>
              <p className="step-description">계약을 체결할 근로자의 기본 정보입니다</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">근로자 성명</label>
              <input 
                name="name" 
                value={form.name} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="성명" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">생년월일</label>
              <input 
                name="birth" 
                type="date" 
                value={form.birth} 
                onChange={handleChange} 
                className="form-input" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">연락처</label>
              <input 
                name="contact" 
                value={form.contact} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="010-0000-0000" 
              />
              <p className="form-help">휴대폰 번호를 입력해주세요</p>
            </div>
          </div>
        );

      case 2: // 근무 기간
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근무 기간을 설정해주세요</h2>
              <p className="step-description">계약의 시작일과 종료일을 입력해주세요</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">근무 시작일</label>
              <input 
                name="periodStart" 
                type="date" 
                value={form.periodStart} 
                onChange={handleChange} 
                className="form-input" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">근무 종료일</label>
              <input 
                name="periodEnd" 
                type="date" 
                value={form.periodEnd} 
                onChange={handleChange} 
                className="form-input" 
              />
              <p className="form-help">기간제 계약의 경우 종료일을, 무기한 계약의 경우 비워두세요</p>
            </div>
          </div>
        );

      case 3: // 근무 요일 선택
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근무 요일을 선택해주세요</h2>
              <p className="step-description">근무하는 요일을 모두 선택해주세요</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">근무 요일</label>
              <div className="day-selector">
                {daysOfWeek.map((day) => (
                  <label key={day} className={`day-option ${form.days.includes(day) ? 'selected' : ''}`}>
                    <input
                      type="checkbox"
                      name="days"
                      value={day}
                      checked={form.days.includes(day)}
                      onChange={handleChange}
                      className="day-checkbox"
                    />
                    <span className="day-text">{day}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 4: // 근무시간 설정
        const workStatsBtn = calcWorkStats(form);
        const getBtnTime = (day) => {
          const mins = form.workTimeType === 'same'
            ? (() => {
                if (!form.commonStart || !form.commonEnd) return 0;
                const s = getMinutes(form.commonStart);
                const e = getMinutes(form.commonEnd);
                const br = Number(form.commonBreak) || 0;
                let work = e > s ? e - s : (e + 24 * 60) - s;
                return Math.max(0, work - br);
              })()
            : (form.dayTimes[day]?.start && form.dayTimes[day]?.end ? workStatsBtn.dayStats[day]?.work || 0 : 0);
          const h = Math.floor(mins / 60);
          const m = mins % 60;
          return mins > 0 ? `[${h}H${m ? '/' + m + 'M' : ''}]` : '';
        };

        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근무시간을 설정해주세요</h2>
              <p className="step-description">출퇴근 시간이 매일 같나요, 요일마다 다르나요?</p>
            </div>
            
            <div className="form-group">
              <div className="time-type-selector">
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, workTimeType: 'same', dayTimes: {} }))} 
                  className={`time-type-btn ${form.workTimeType === 'same' ? 'active' : ''}`}
                >
                  매일 같다
                </button>
                <button 
                  type="button" 
                  onClick={() => setForm(f => ({ ...f, workTimeType: 'diff', commonStart: '', commonEnd: '', commonBreak: '' }))} 
                  className={`time-type-btn ${form.workTimeType === 'diff' ? 'active' : ''}`}
                >
                  요일마다 다르다
                </button>
              </div>
            </div>

            {form.workTimeType === 'same' && (
              <>
                <div className="form-group">
                  <label className="form-label">출근 시간</label>
                  <input 
                    name="commonStart" 
                    type="time" 
                    value={form.commonStart} 
                    onChange={handleChange} 
                    className="form-input" 
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">퇴근 시간</label>
                  <input 
                    name="commonEnd" 
                    type="time" 
                    value={form.commonEnd} 
                    onChange={handleChange} 
                    className="form-input" 
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">휴게시간 (분)</label>
                  <input 
                    name="commonBreak" 
                    type="number" 
                    value={form.commonBreak} 
                    onChange={handleChange} 
                    className="form-input" 
                    min={0} 
                    placeholder="60" 
                  />
                </div>
              </>
            )}

            {form.workTimeType === 'diff' && (
              <div className="form-group">
                <label className="form-label">요일별 근무시간</label>
                <div className="day-times">
                  {form.days.map((day) => (
                    <div key={day} className="day-time-item">
                      <div className="day-time-header">
                        <span className="day-time-day">{day}</span>
                        <span className="day-time-summary">{getBtnTime(day)}</span>
                      </div>
                      <div className="day-time-inputs">
                        <input
                          type="time"
                          name="dayStart"
                          data-day={day}
                          value={form.dayTimes[day]?.start || ''}
                          onChange={handleChange}
                          className="form-input time-input"
                          placeholder="출근"
                        />
                        <span className="time-separator">~</span>
                        <input
                          type="time"
                          name="dayEnd"
                          data-day={day}
                          value={form.dayTimes[day]?.end || ''}
                          onChange={handleChange}
                          className="form-input time-input"
                          placeholder="퇴근"
                        />
                        <input
                          type="number"
                          name="dayBreak"
                          data-day={day}
                          value={form.dayTimes[day]?.break || ''}
                          onChange={handleChange}
                          className="form-input break-input"
                          min={0}
                          placeholder="휴게(분)"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {form.workTimeType && (
              <div className="work-summary">
                <WorkTimeSummary form={form} />
              </div>
            )}
          </div>
        );

      case 5: // 임금 정보
        const workStats3 = calcWorkStats(form);
        const basePay = form.wage ? Number(form.wage) : 0;
        const baseMonth = workStats3.totalMonth;
        const baseSalary = Math.round(basePay * (baseMonth / 60));

        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">임금 정보를 입력해주세요</h2>
              <p className="step-description">근로자의 임금 조건을 설정해주세요</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">시급 (원)</label>
              <input 
                name="wage" 
                type="number" 
                value={form.wage} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="9860" 
              />
              <p className="form-help">2024년 최저임금: 9,860원/시간</p>
            </div>

            <div className="form-group">
              <label className="form-label">임금 지급일</label>
              <input 
                name="payday" 
                value={form.payday} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 매월 10일" 
              />
            </div>

            {basePay > 0 && baseMonth > 0 && (
              <div className="salary-preview">
                <h3 className="salary-preview-title">임금 미리보기</h3>
                <div className="salary-preview-content">
                  <div className="salary-item">
                    <span className="salary-label">시급:</span>
                    <span className="salary-value">{basePay.toLocaleString()}원</span>
                  </div>
                  <div className="salary-item">
                    <span className="salary-label">월 예상 급여:</span>
                    <span className="salary-value">{baseSalary.toLocaleString()}원</span>
                  </div>
                  <div className="salary-item">
                    <span className="salary-label">야간근로수당:</span>
                    <span className="salary-value">{getHourStr(workStats3.night)}</span>
                  </div>
                  <div className="salary-item">
                    <span className="salary-label">연장근로수당:</span>
                    <span className="salary-value">{getHourStr(workStats3.over)}</span>
                  </div>
                </div>
                <p className="salary-note">※ 이 정보는 참고용이며, 계약서에는 포함되지 않습니다.</p>
              </div>
            )}
          </div>
        );

      case 6: // 업무 및 기타
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">업무 및 기타 조건을 입력해주세요</h2>
              <p className="step-description">근로계약서의 마지막 세부사항입니다</p>
            </div>
            
            <div className="form-group">
              <label className="form-label">업무 내용</label>
              <input 
                name="jobDesc" 
                value={form.jobDesc} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 주방 보조, 서빙, 정리정돈" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">휴게 시간</label>
              <input 
                name="breakTime" 
                value={form.breakTime} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 1시간" 
              />
            </div>

            <div className="form-group">
              <label className="form-label">계약 해지 조건</label>
              <input 
                name="termination" 
                value={form.termination} 
                onChange={handleChange} 
                className="form-input" 
                placeholder="예: 1개월 전 서면 통지" 
              />
            </div>
          </div>
        );

      case 7: // 미리보기
        return (
          <div className="step-container">
            <div className="step-header">
              <h2 className="step-title">근로계약서 미리보기</h2>
              <p className="step-description">작성한 내용을 확인하고 PDF로 저장하세요</p>
            </div>
            
            <div className="preview-container" ref={previewRef}>
              <h3 className="preview-title">근로계약서 (표준 양식)</h3>
              <table className="preview-table">
                <tbody>
                  <tr>
                    <th className="preview-th">사업장명</th>
                    <td className="preview-td">{form.storeName || '-'}</td>
                    <th className="preview-th">대표자</th>
                    <td className="preview-td">{form.owner || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">사업장 주소</th>
                    <td className="preview-td" colSpan="3">
                      {form.address || '-'} {form.addressDetail || ''}
                    </td>
                  </tr>
                  <tr>
                    <th className="preview-th">근로자 성명</th>
                    <td className="preview-td">{form.name || '-'}</td>
                    <th className="preview-th">생년월일</th>
                    <td className="preview-td">{form.birth || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">연락처</th>
                    <td className="preview-td" colSpan="3">{form.contact || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">근무기간</th>
                    <td className="preview-td" colSpan="3">
                      {form.periodStart || '-'} ~ {form.periodEnd || '무기한'}
                    </td>
                  </tr>
                  <tr>
                    <th className="preview-th">근무요일</th>
                    <td className="preview-td" colSpan="3">
                      {form.days.length > 0 ? form.days.join(', ') : '-'}
                    </td>
                  </tr>
                  <tr>
                    <th className="preview-th">근무시간</th>
                    <td className="preview-td" colSpan="3">
                      {form.workTimeType === 'same' 
                        ? `${form.commonStart || '-'} ~ ${form.commonEnd || '-'} (휴게: ${form.commonBreak || 0}분)`
                        : '요일별 상이'
                      }
                    </td>
                  </tr>
                  <tr>
                    <th className="preview-th">시급</th>
                    <td className="preview-td">{form.wage ? `${form.wage}원` : '-'}</td>
                    <th className="preview-th">지급일</th>
                    <td className="preview-td">{form.payday || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">업무내용</th>
                    <td className="preview-td" colSpan="3">{form.jobDesc || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">휴게시간</th>
                    <td className="preview-td" colSpan="3">{form.breakTime || '-'}</td>
                  </tr>
                  <tr>
                    <th className="preview-th">해지조건</th>
                    <td className="preview-td" colSpan="3">{form.termination || '-'}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="preview-actions">
              <button 
                onClick={handleSavePDF} 
                className="save-pdf-btn"
              >
                📄 PDF 저장하기
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="contract-form-page">
      <div className="contract-form-container">
        {/* Header */}
        <div className="form-header">
          <button onClick={() => navigate('/')} className="back-btn">
            ← 홈으로
          </button>
          <h1 className="form-title">근로계약서 작성</h1>
          <div className="header-spacer"></div>
        </div>
        
        {/* Progress Bar */}
        <div className="progress-container">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${((step + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
          <div className="progress-text">
            {step + 1} / {steps.length}
          </div>
        </div>

        {/* Step Indicator */}
        <div className="step-indicator">
          {steps.map((stepName, index) => (
            <div key={index} className={`step-dot ${index <= step ? 'active' : ''} ${index === step ? 'current' : ''}`}>
              <span className="step-number">{index + 1}</span>
              <span className="step-name">{stepName}</span>
            </div>
          ))}
        </div>
        
        {/* Step Content */}
        <div className="step-content">
          {renderStep()}
        </div>
        
        {/* Navigation Buttons */}
        <div className="navigation-buttons">
          <button 
            onClick={() => setStep(Math.max(0, step - 1))} 
            className={`nav-btn prev-btn ${step === 0 ? 'hidden' : ''}`}
          >
            ← 이전
          </button>
          <button 
            onClick={() => setStep(Math.min(steps.length - 1, step + 1))} 
            className={`nav-btn next-btn ${step === steps.length - 1 ? 'hidden' : ''}`}
          >
            다음 →
          </button>
        </div>
      </div>
    </div>
  );
}

// 근무시간 안내 컴포넌트 분리
function WorkTimeSummary({ form }) {
  const workStats = calcWorkStats(form);
  return (
    <div className="work-time-summary">
      <h3 className="summary-title">근무시간 요약</h3>
      <div className="summary-content">
        <div className="summary-item">
          <span className="summary-label">주당 근무시간:</span>
          <span className="summary-value">{getHourStr(workStats.totalWeek)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">월간 근무시간(예상):</span>
          <span className="summary-value">{getHourStr(workStats.totalMonth)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">야간근로(22:00~06:00):</span>
          <span className="summary-value">{getHourStr(workStats.night)}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">연장근로(1일 8시간 초과):</span>
          <span className="summary-value">{getHourStr(workStats.over)}</span>
        </div>
      </div>
      <p className="summary-note">※ 월평균 4.345주 기준으로 계산됩니다</p>
    </div>
  );
}

export default ContractForm; 